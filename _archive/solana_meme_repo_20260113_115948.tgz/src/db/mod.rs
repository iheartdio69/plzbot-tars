use anyhow::Result;
use rusqlite::{params, Connection};
use std::path::{Path, PathBuf};
pub struct Db {
    conn: Connection,
}

impl Db {
    pub fn open(path: &str) -> Result<Self> {
        // --- DEBUG: print the db path we are actually using ---
        let abs: PathBuf = std::fs::canonicalize(path)
            .unwrap_or_else(|_| std::env::current_dir().unwrap().join(path));

        eprintln!("🗄️ Db::open path(arg) = {}", path);
        eprintln!("🗄️ Db::open path(abs) = {}", abs.display());

        let _create_new = !Path::new(path).exists();
        let conn = Connection::open(path)?;
        conn.pragma_update(None, "foreign_keys", "ON")?;

        // Apply schema (idempotent)
        let schema = include_str!("schema.sql");
        conn.execute_batch(schema)?;

        // ---- calls.tag migration (safe) ----
        // Adds calls.tag if it doesn't exist (older DBs)
        let has_calls_tag = {
            let mut has = false;
            let mut stmt = conn.prepare("PRAGMA table_info(calls)")?;
            let mut rows = stmt.query([])?;
            while let Some(r) = rows.next()? {
                let name: String = r.get(1)?; // column name
                if name == "tag" {
                    has = true;
                    break;
                }
            }
            has
        };

        if !has_calls_tag {
            conn.execute_batch("ALTER TABLE calls ADD COLUMN tag TEXT NOT NULL DEFAULT '';")?;
        }

        // -------------------------
        // wallet_scoring_state safety + migration
        // -------------------------
        // Ensure table exists (in case schema.sql is older)
        conn.execute_batch(
            r#"
            CREATE TABLE IF NOT EXISTS wallet_scoring_state (
              id             INTEGER PRIMARY KEY CHECK (id = 1),
              last_scored_ts INTEGER NOT NULL DEFAULT 0
            );
            INSERT OR IGNORE INTO wallet_scoring_state (id, last_scored_ts) VALUES (1, 0);
            "#,
        )?;

        // Detect column drift: some DBs may have last_ts instead of last_scored_ts
        let (has_last_scored_ts, has_last_ts) = {
            let mut has_scored = false;
            let mut has_last = false;
            let mut stmt = conn.prepare("PRAGMA table_info(wallet_scoring_state)")?;
            let mut rows = stmt.query([])?;
            while let Some(r) = rows.next()? {
                let name: String = r.get(1)?; // column name
                if name == "last_scored_ts" {
                    has_scored = true;
                } else if name == "last_ts" {
                    has_last = true;
                }
            }
            (has_scored, has_last)
        };

        // If last_scored_ts is missing, add it.
        if !has_last_scored_ts {
            conn.execute_batch(
                "ALTER TABLE wallet_scoring_state ADD COLUMN last_scored_ts INTEGER NOT NULL DEFAULT 0;",
            )?;
            // Ensure row exists for id=1 (older DBs might lack it)
            let _ = conn.execute(
                "INSERT OR IGNORE INTO wallet_scoring_state (id, last_scored_ts) VALUES (1, 0)",
                [],
            )?;
        }

        // Backfill last_scored_ts from last_ts if present and last_scored_ts is 0
        if has_last_ts {
            conn.execute_batch(
                r#"
                UPDATE wallet_scoring_state
                SET last_scored_ts = CASE
                  WHEN last_scored_ts IS NULL OR last_scored_ts = 0 THEN COALESCE(last_ts, 0)
                  ELSE last_scored_ts
                END
                WHERE id = 1;
                "#,
            )?;
        }

        Ok(Self { conn })
    }

    pub fn fdv_change_pct(&mut self, mint: &str, now_ts: i64, lookback_secs: i64) -> Option<f64> {
        let since = now_ts - lookback_secs;

        let mut stmt = self
            .conn
            .prepare(
                r#"
        SELECT fdv_usd
        FROM mint_snapshots
        WHERE mint = ?1
          AND ts >= ?2
          AND fdv_usd IS NOT NULL
        ORDER BY ts ASC
        LIMIT 1
        "#,
            )
            .ok()?;

        let old_fdv: f64 = stmt.query_row(params![mint, since], |r| r.get(0)).ok()?;

        let mut stmt2 = self
            .conn
            .prepare(
                r#"
        SELECT fdv_usd
        FROM mint_snapshots
        WHERE mint = ?1
          AND fdv_usd IS NOT NULL
        ORDER BY ts DESC
        LIMIT 1
        "#,
            )
            .ok()?;

        let new_fdv: f64 = stmt2.query_row(params![mint], |r| r.get(0)).ok()?;

        if old_fdv <= 0.0 {
            return None;
        }

        Some((new_fdv - old_fdv) / old_fdv)
    }

    // =========================
    // Wallet learning writes
    // =========================

    /// Ensure a wallet exists in `wallets` and update last_seen_ts.
    pub fn touch_wallet(&mut self, wallet: &str, ts: i64) -> Result<()> {
        self.conn.execute(
            r#"
            INSERT INTO wallets (wallet, score, last_seen_ts, notes)
            VALUES (?1, 0, ?2, NULL)
            ON CONFLICT(wallet) DO UPDATE SET
              last_seen_ts = CASE
                WHEN wallets.last_seen_ts IS NULL OR wallets.last_seen_ts < excluded.last_seen_ts
                THEN excluded.last_seen_ts
                ELSE wallets.last_seen_ts
              END
            "#,
            params![wallet, ts],
        )?;
        Ok(())
    }

    /// Add an observation edge (src -> dst) to `wallet_edges`.
    pub fn insert_wallet_edge(
        &mut self,
        ts: i64,
        src_wallet: &str,
        dst_wallet: Option<&str>,
        mint: Option<&str>,
        action: &str,
        sol: Option<f64>,
        sig: Option<&str>,
    ) -> Result<()> {
        // keep wallet table warm
        self.touch_wallet(src_wallet, ts)?;
        if let Some(dst) = dst_wallet {
            self.touch_wallet(dst, ts)?;
        }

        self.conn.execute(
            r#"
            INSERT INTO wallet_edges (ts, src_wallet, dst_wallet, mint, action, sol, sig)
            VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)
            "#,
            params![ts, src_wallet, dst_wallet, mint, action, sol, sig],
        )?;
        Ok(())
    }

    // =========================
    // Wallet reputation reads/writes
    // =========================

    pub fn wallet_score(&mut self, wallet: &str) -> Result<i64> {
        let mut stmt = self
            .conn
            .prepare("SELECT COALESCE(score, 0) FROM wallets WHERE wallet=?1")?;
        let v: i64 = stmt.query_row(params![wallet], |r| r.get(0)).unwrap_or(0);
        Ok(v)
    }

    // =========================
    // Call-time wallet fingerprints
    // =========================

    /// Top wallets by *edge count* for a mint in a recent time window.
    /// This is our best proxy right now for "top holders / most involved wallets"
    /// until we add real token-balance holders via RPC.
    pub fn top_wallets_by_edges_recent(
        &mut self,
        mint: &str,
        now_ts: i64,
        lookback_secs: i64,
        limit: i64,
    ) -> Result<Vec<(String, i64)>> {
        let since = now_ts - lookback_secs.max(1);

        let mut stmt = self.conn.prepare(
            r#"
        SELECT src_wallet, COUNT(*) AS edges
        FROM wallet_edges
        WHERE mint = ?1 AND ts >= ?2 AND ts <= ?3
        GROUP BY src_wallet
        ORDER BY edges DESC
        LIMIT ?4
        "#,
        )?;

        let mut rows = stmt.query(params![mint, since, now_ts, limit])?;
        let mut out: Vec<(String, i64)> = Vec::new();

        while let Some(r) = rows.next()? {
            let w: String = r.get(0)?;
            let edges: i64 = r.get(1)?;
            out.push((w, edges));
        }

        Ok(out)
    }

    /// "Early cluster" wallets: wallets that appear right near mint’s first activity.
    /// Captures degens who are consistently early even if they don't become top-edges later.
    pub fn early_wallets_for_mint(
        &mut self,
        mint: &str,
        early_window_secs: i64,
        limit: i64,
    ) -> Result<Vec<(String, i64, i64)>> {
        // find first edge ts for this mint
        let mut stmt0 = self.conn.prepare(
            r#"
        SELECT COALESCE(MIN(ts), 0)
        FROM wallet_edges
        WHERE mint = ?1
        "#,
        )?;
        let first_ts: i64 = stmt0.query_row(params![mint], |r| r.get(0)).unwrap_or(0);
        if first_ts <= 0 {
            return Ok(vec![]);
        }

        let cutoff = first_ts + early_window_secs.max(1);

        let mut stmt = self.conn.prepare(
            r#"
        SELECT
          src_wallet,
          COUNT(*) AS edges,
          MIN(ts) AS first_seen_ts
        FROM wallet_edges
        WHERE mint = ?1 AND ts >= ?2 AND ts <= ?3
        GROUP BY src_wallet
        ORDER BY first_seen_ts ASC, edges DESC
        LIMIT ?4
        "#,
        )?;

        let mut rows = stmt.query(params![mint, first_ts, cutoff, limit])?;
        let mut out: Vec<(String, i64, i64)> = Vec::new();

        while let Some(r) = rows.next()? {
            let w: String = r.get(0)?;
            let edges: i64 = r.get(1)?;
            let seen: i64 = r.get(2)?;
            out.push((w, edges, seen));
        }

        Ok(out)
    }

    pub fn insert_call_top_wallet(
        &mut self,
        mint: &str,
        call_ts: i64,
        wallet: &str,
        edges: i64,
    ) -> Result<()> {
        self.conn.execute(
            r#"
        INSERT OR REPLACE INTO call_top_wallets (mint, call_ts, wallet, edges)
        VALUES (?1, ?2, ?3, ?4)
        "#,
            params![mint, call_ts, wallet, edges],
        )?;
        Ok(())
    }

    pub fn insert_call_wallet_fingerprint(
        &mut self,
        mint: &str,
        call_ts: i64,
        wallet: &str,
        reason: &str,
        metric: f64,
    ) -> Result<()> {
        self.conn.execute(
            r#"
        INSERT OR REPLACE INTO call_wallet_fingerprints (mint, call_ts, wallet, reason, metric)
        VALUES (?1, ?2, ?3, ?4, ?5)
        "#,
            params![mint, call_ts, wallet, reason, metric],
        )?;
        Ok(())
    }

    /// Top wallets for a mint by edge count (last N minutes).
    /// Returns Vec<(wallet, edges)>
    pub fn top_wallets_for_mint(&mut self, mint: &str, limit: i64) -> Result<Vec<(String, i64)>> {
        // lookback window: 20 minutes (matches your event retention)
        let since = crate::time::now() as i64 - 1200;

        let mut stmt = self.conn.prepare(
            r#"
        SELECT src_wallet, COUNT(*) AS edges
        FROM wallet_edges
        WHERE mint = ?1
          AND ts >= ?2
        GROUP BY src_wallet
        ORDER BY edges DESC
        LIMIT ?3
        "#,
        )?;

        let mut rows = stmt.query(params![mint, since, limit])?;
        let mut out: Vec<(String, i64)> = Vec::new();

        while let Some(r) = rows.next()? {
            let wallet: String = r.get(0)?;
            let edges: i64 = r.get(1)?;
            out.push((wallet, edges));
        }

        Ok(out)
    }

    /// Upsert into watchlist_wallets and merge tags.
    /// Keeps a growing list you can export to Axiom later.
    pub fn watchlist_touch_with_tag(&mut self, wallet: &str, ts: i64, tag: &str) -> Result<()> {
        // ensure row exists
        self.conn.execute(
        r#"
        INSERT INTO watchlist_wallets (wallet, first_seen_ts, last_seen_ts, tags, wins, losses)
        VALUES (?1, ?2, ?2, ?3, 0, 0)
        ON CONFLICT(wallet) DO UPDATE SET
          last_seen_ts = CASE
            WHEN watchlist_wallets.last_seen_ts IS NULL OR watchlist_wallets.last_seen_ts < excluded.last_seen_ts
            THEN excluded.last_seen_ts
            ELSE watchlist_wallets.last_seen_ts
          END,
          tags = CASE
            WHEN watchlist_wallets.tags IS NULL OR watchlist_wallets.tags = '' THEN excluded.tags
            WHEN instr(',' || watchlist_wallets.tags || ',', ',' || excluded.tags || ',') > 0 THEN watchlist_wallets.tags
            ELSE watchlist_wallets.tags || ',' || excluded.tags
          END
        "#,
        params![wallet, ts, tag],
    )?;
        Ok(())
    }

    pub fn fdv_delta_recent(&self, mint: &str, now_ts: i64, window_secs: i64) -> Result<f64> {
        let since = now_ts - window_secs.max(1);

        let mut stmt = self.conn.prepare(
        r#"
        SELECT
          (SELECT fdv_usd FROM mint_snapshots WHERE mint=?1 AND ts<=?2 AND fdv_usd IS NOT NULL ORDER BY ts DESC LIMIT 1) AS fdv_now,
          (SELECT fdv_usd FROM mint_snapshots WHERE mint=?1 AND ts>=?3 AND fdv_usd IS NOT NULL ORDER BY ts ASC  LIMIT 1) AS fdv_then
        "#,
    )?;

        let (fdv_now, fdv_then): (Option<f64>, Option<f64>) =
            stmt.query_row(params![mint, now_ts, since], |r| Ok((r.get(0)?, r.get(1)?)))?;

        Ok(fdv_now.unwrap_or(0.0) - fdv_then.unwrap_or(0.0))
    }

    /// Helpful for printing "known wallets" when you call something.
    pub fn watchlist_has_wallet(&mut self, wallet: &str) -> Result<bool> {
        let mut stmt = self
            .conn
            .prepare(r#"SELECT 1 FROM watchlist_wallets WHERE wallet=?1 LIMIT 1"#)?;
        let mut rows = stmt.query(params![wallet])?;
        Ok(rows.next()?.is_some())
    }

    /// Canonical last-scored timestamp for wallet scoring.
    /// We store it in wallet_scoring_state.last_scored_ts.
    pub fn wallet_scoring_last_ts(&mut self) -> Result<i64> {
        let mut stmt = self.conn.prepare(
            r#"
            SELECT COALESCE(last_scored_ts, 0)
            FROM wallet_scoring_state
            WHERE id = 1
            "#,
        )?;
        let v: i64 = stmt.query_row([], |r| r.get(0)).unwrap_or(0);
        Ok(v)
    }

    /// Set last scored ts. If your DB also has `last_ts`, we update it too (if exists).
    pub fn wallet_scoring_set_last_ts(&mut self, ts: i64) -> Result<()> {
        // Always update canonical column
        self.conn.execute(
            r#"
            UPDATE wallet_scoring_state
            SET last_scored_ts = ?1
            WHERE id = 1
            "#,
            params![ts],
        )?;

        // If legacy column exists, update it too
        let has_last_ts = {
            let mut has = false;
            let mut stmt = self
                .conn
                .prepare("PRAGMA table_info(wallet_scoring_state)")?;
            let mut rows = stmt.query([])?;
            while let Some(r) = rows.next()? {
                let name: String = r.get(1)?;
                if name == "last_ts" {
                    has = true;
                    break;
                }
            }
            has
        };

        if has_last_ts {
            let _ = self.conn.execute(
                r#"
                UPDATE wallet_scoring_state
                SET last_ts = ?1
                WHERE id = 1
                "#,
                params![ts],
            )?;
        }

        Ok(())
    }

    /// Compute raw deltas from wallet_edges between (since_ts, now_ts].
    pub fn wallet_scoring_compute_deltas(
        &mut self,
        since_ts: i64,
        now_ts: i64,
    ) -> Result<Vec<(String, i64)>> {
        let mut stmt = self.conn.prepare(
            r#"
            SELECT
              src_wallet,
              COUNT(*) AS edges,
              COUNT(DISTINCT mint) AS uniq_mints,
              MIN(ts) AS first_ts,
              MAX(ts) AS last_ts
            FROM wallet_edges
            WHERE ts > ?1 AND ts <= ?2
            GROUP BY src_wallet
            "#,
        )?;

        let mut rows = stmt.query(params![since_ts, now_ts])?;
        let mut out: Vec<(String, i64)> = Vec::new();

        while let Some(r) = rows.next()? {
            let wallet: String = r.get(0)?;
            let edges: i64 = r.get(1)?;
            let uniq_mints: i64 = r.get(2)?;
            let first_ts: i64 = r.get(3)?;
            let last_ts: i64 = r.get(4)?;

            if edges <= 0 {
                continue;
            }

            // ----- base gain -----
            // Small base reward per edges, not crazy.
            let mut delta: i64 = (edges / 6).max(1); // 6 edges -> +1

            // ----- mint diversity reward -----
            if uniq_mints >= 3 {
                delta += 10;
            }
            if uniq_mints >= 10 {
                delta += 20;
            }
            if uniq_mints >= 25 {
                delta += 25;
            }

            // ----- concentration / bot penalty (STRONG) -----
            if uniq_mints <= 1 {
                // Heavy hammer: 100+ edges on one mint in a window is almost always automation.
                if edges >= 200 {
                    delta -= 400;
                } else if edges >= 120 {
                    delta -= 250;
                } else if edges >= 100 {
                    delta -= 175;
                } else if edges >= 60 {
                    delta -= 90;
                } else if edges >= 40 {
                    delta -= 45;
                }

                // Single-mint wallets should never go positive.
                delta = delta.min(0);
            } else {
                // ratio-based soft cap: uniq_mints/edges
                let ratio_times_1000 = (uniq_mints * 1000) / edges.max(1);
                if edges >= 80 && ratio_times_1000 <= 25 {
                    delta = delta.min(5);
                } else if edges >= 50 && ratio_times_1000 <= 50 {
                    delta = delta.min(12);
                }
            }

            // ----- burst cap -----
            let span = (last_ts - first_ts).max(1);
            if edges >= 120 && span <= 90 {
                delta = delta.min(5);
            } else if edges >= 80 && span <= 120 {
                delta = delta.min(10);
            }

            // ----- final per-run cap -----
            // widen negative clamp because we now use heavier penalties
            delta = delta.clamp(-500, 50);

            out.push((wallet, delta));
        }

        Ok(out)
    }

    /// Smooth update:
    /// - ensures wallet exists
    /// - decays old score slightly
    /// - adds delta
    pub fn wallet_score_smooth_update(&mut self, wallet: &str, delta: i64, ts: i64) -> Result<()> {
        self.touch_wallet(wallet, ts)?;

        // score = floor(score*0.98) + delta
        self.conn.execute(
            r#"
            UPDATE wallets
            SET score = CAST(score * 0.98 AS INTEGER) + ?2,
                last_seen_ts = CASE
                  WHEN last_seen_ts IS NULL OR last_seen_ts < ?3 THEN ?3
                  ELSE last_seen_ts
                END
            WHERE wallet = ?1
            "#,
            params![wallet, delta, ts],
        )?;
        Ok(())
    }

    // =========================
    // Snapshots + calls
    // =========================

    pub fn insert_snapshot(
        &mut self,
        ts: i64,
        mint: &str,
        fdv_usd: Option<f64>,
        tx_5m: Option<u64>,
        score: i32,
        signers_5m: u64,
        events: usize,
        first_seen: u64,
        is_active: bool,
        is_call: bool,
    ) -> Result<()> {
        self.conn.execute(
            r#"
            INSERT INTO mint_snapshots
              (ts, mint, fdv_usd, tx_5m, score, signers_5m, events, first_seen, is_active, is_call)
            VALUES
              (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10)
            "#,
            params![
                ts,
                mint,
                fdv_usd,
                tx_5m.map(|x| x as i64),
                score,
                signers_5m as i64,
                events as i64,
                first_seen as i64,
                if is_active { 1 } else { 0 },
                if is_call { 1 } else { 0 },
            ],
        )?;
        Ok(())
    }

    pub fn insert_call(
        &mut self,
        ts: i64,
        mint: &str,
        fdv_usd: f64,
        score: i32,
        tx_5m: u64,
        signers_5m: u64,
        events: usize,
        tag: Option<&str>,
    ) -> Result<()> {
        self.conn.execute(
            r#"
        INSERT INTO calls (ts, mint, fdv_usd, score, tx_5m, signers_5m, events, tag)
        VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)
        "#,
            params![
                ts,
                mint,
                fdv_usd,
                score,
                tx_5m as i64,
                signers_5m as i64,
                events as i64,
                tag.unwrap_or(""),
            ],
        )?;
        Ok(())
    }

    // =========================
    // Dedupe
    // =========================

    pub fn seen_sig(&mut self, sig: &str) -> Result<bool> {
        let mut stmt = self
            .conn
            .prepare("SELECT 1 FROM seen_sigs WHERE sig=?1 LIMIT 1")?;
        let mut rows = stmt.query(params![sig])?;
        Ok(rows.next()?.is_some())
    }

    pub fn mark_sig(&mut self, ts: i64, sig: &str) -> Result<()> {
        self.conn.execute(
            "INSERT OR IGNORE INTO seen_sigs (sig, ts) VALUES (?1, ?2)",
            params![sig, ts],
        )?;
        Ok(())
    }

    pub fn signers_5m(&self, now_ts: i64, mint: &str) -> Result<u64> {
        let since = now_ts - 300;
        let mut stmt = self.conn.prepare(
            r#"
        SELECT COUNT(DISTINCT src_wallet)
        FROM wallet_edges
        WHERE mint = ?1
          AND ts >= ?2
          AND ts <= ?3
        "#,
        )?;
        let n: i64 = stmt.query_row(params![mint, since, now_ts], |r| r.get(0))?;
        Ok(n as u64)
    }
}
