use crate::config::Config;
use crate::db::Db;
use crate::helius::types::HeliusTx;
use crate::helius::utils::{classify_tier, collect_mints, estimate_sol_outflow};
use crate::types::{CoinState, Event};
use reqwest::Client;
use std::collections::{HashMap, HashSet};

/// Fetch recent txs for currently tracked mint addresses.
/// - Push whale-ish events into CoinState.events (same spirit as before)
/// - Return discovered mints seen in tokenTransfers (to widen scanning)
/// - Write wallet->mint observations into SQLite
pub async fn fetch_onchain_events(
    cfg: &crate::config::Config,
    db: &mut crate::db::Db,
    coins: &mut std::collections::HashMap<String, crate::types::CoinState>,
    tracked: &[String],
) -> Vec<String> {
    use crate::helius::types::HeliusTx;
    use crate::helius::utils::{collect_mints, estimate_sol_outflow};
    use crate::types::Event;
    use std::collections::HashSet;

    if cfg.helius_api_key.trim().is_empty() {
        return vec![];
    }

    let base = if cfg.helius_api_base.trim().is_empty() {
        "https://api.helius.xyz".to_string()
    } else {
        cfg.helius_api_base.clone()
    };

    let client = reqwest::Client::new();
    let mut discovered: HashSet<String> = HashSet::new();

    for addr in tracked {
        let url = format!(
            "{}/v0/addresses/{}/transactions?api-key={}&limit={}",
            base,
            addr,
            cfg.helius_api_key,
            cfg.helius_tx_limit
        );

        let resp = match client.get(&url).send().await {
            Ok(r) => r,
            Err(_) => continue,
        };
        if !resp.status().is_success() {
            continue;
        }

        let txs: Vec<HeliusTx> = match resp.json().await {
            Ok(v) => v,
            Err(_) => continue,
        };

        // If we have a coin state for this address (sometimes you track mints, sometimes wallets),
        // we'll attach events to it. If not, we'll just record discovery.
        let maybe_state = coins.get_mut(addr);

        for tx in txs.iter() {
            let ts = tx.timestamp.unwrap_or(0) as i64;
            let actor = tx.fee_payer.clone().unwrap_or_else(|| addr.clone());
            let sig = tx.signature.as_deref();

            // Discover mints from token transfers
            for m in collect_mints(&tx.token_transfers) {
                discovered.insert(m.clone());

                // Record a wallet_edge observation (best-effort)
                // insert_wallet_edge(ts, src_wallet, dst_wallet, mint, action, sol, sig)
                let _ = db.insert_wallet_edge(
                    ts,
                    &actor,
                    None,
                    Some(m.as_str()),
                    Some("token_transfer"),
                    None,
                    sig,
                );

                // Also attach an event if we have state
                if let Some(state) = maybe_state.as_ref() {
                    // no-op; we can’t mut-borrow twice here
                    let _ = state;
                }
            }

            // Estimate SOL outflow from native transfers
            let sol_out = estimate_sol_outflow(&tx.native_transfers, &actor);
            if sol_out > 0.0 {
                let _ = db.insert_wallet_edge(
                    ts,
                    &actor,
                    None,
                    None,
                    Some("sol_outflow"),
                    Some(sol_out),
                    sig,
                );
            }

            // Attach a lightweight event if we do have a state for this tracked address
            if let Some(state) = coins.get_mut(addr) {
                state.events.push(Event {
                    ts: ts as u64,
                    wallet: actor.clone(),
                    mint: None,
                    action: "helius_tx".to_string(),
                    sol: Some(sol_out),
                    sig: sig.map(|x| x.to_string()),
                });
            }
        }
    }

    discovered.into_iter().collect::<Vec<String>>()
}

