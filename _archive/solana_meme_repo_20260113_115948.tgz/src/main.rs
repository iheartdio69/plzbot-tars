mod call_log;
mod config;
mod db;
mod fmt;
mod gambol_log;
mod helius;
mod io;
mod market;
mod printing;
mod pumpportal;
mod resolver;
mod scoring;
mod time;
mod types;

use crate::config::load_config;
use crate::io::{load_reputation, save_reputation};
use crate::market::cache::MarketCache;
use crate::market::discovery::{merge_discovered, MarketDiscovery};
use crate::types::{CallRecord, CoinState};

use std::collections::{HashMap, VecDeque};
use std::time::Duration;
use tokio::signal;
use tokio::sync::mpsc;

#[tokio::main]
async fn main() {
    let cfg = load_config();

    if let Err(e) = load_reputation() {
        eprintln!(
            "{}⚠️ Failed to load reputation files:{} {}",
            fmt::ORANGE,
            fmt::RESET,
            e
        );
    }

    // autosave (every 300s)
    tokio::spawn(async move {
        loop {
            tokio::time::sleep(Duration::from_secs(300)).await;
            let _ = save_reputation();
        }
    });

    // Bot state
    let mut coins: HashMap<String, CoinState> = HashMap::new();
    let mut active: Vec<String> = Vec::new();
    let mut queue: VecDeque<String> = VecDeque::new();
    let mut calls: Vec<CallRecord> = Vec::new();

    let mut market = MarketCache::default();
    let mut discovered: VecDeque<String> = VecDeque::new();
    let mut discovery = MarketDiscovery::default();
    let mut shadow = scoring::shadow::ShadowMap::new();

    // ✅ ONE canonical DB open (from config/.env)
    let mut db = crate::db::Db::open(&cfg.sqlite_path).expect("db open failed");

    // PumpPortal -> stream new token mints into the bot
    let (pump_tx, mut pump_rx) = mpsc::channel::<String>(10_000);
    let cfg_pp = cfg.clone();
    tokio::spawn(async move {
        pumpportal::client::run(cfg_pp, pump_tx).await;
    });

    println!(
        "{}🚀 Solana Meme Sniper started{} (Ctrl+C to stop)",
        fmt::NEON_GREEN,
        fmt::RESET
    );

    tokio::select! {
                    _ = async {
                        loop {
                            // 1) Drain PumpPortal mints (fast path)
                            let mut pump_added = 0usize;
                            while let Ok(mint) = pump_rx.try_recv() {
                                if !coins.contains_key(&mint) {
                                    coins.entry(mint.clone()).or_insert_with(CoinState::new);
                                    discovered.push_back(mint);
                                    pump_added += 1;

                                    while discovered.len() > 20_000 {
                                        discovered.pop_front();
                                    }
                                }
                            }

                            if pump_added > 0 {
                                println!(
                                    "{}🟣 pumpportal{} added={} coins={}",
                                    fmt::NEON_PINK, fmt::RESET, pump_added, coins.len()
                                );
                            }

                            // 2) Periodic discovery (slow path)
                            if discovery.should_run(&cfg) {
                                let new_mints = discovery.run(&cfg).await;
                                let added = merge_discovered(&mut discovered, new_mints.clone(), 2_000);

                                if added > 0 {
                                    println!(
                                        "{}🕵️ discovery{} got={} added={} coins={}",
                                        fmt::LIGHT_BLUE, fmt::RESET, new_mints.len(), added, coins.len()
                                    );
                                    for mint in new_mints {
                                        coins.entry(mint).or_insert_with(CoinState::new);
                                    }
                                }
                            }

                            println!(
                                "{}🫀 tick{} coins={} active={} calls={} discovered={}",
                                fmt::ORANGE, fmt::RESET,
                                coins.len(),
                                active.len(),
                                calls.len(),
                                discovered.len()
                            );

                            // 3) Market polling (Dex)
                            let mint_list: Vec<String> = coins.keys().cloned().collect();
                            market.poll(&cfg, &mint_list).await;
                            // ✅ propagate Dex pair_address into CoinState so per-coin Helius ingest can work
            for (mint, st) in coins.iter_mut() {
                if st.pair_address.is_none() {
                    if let Some(ms) = market.map.get(mint) {
                        if let Some(pa) = ms.pair_address.as_ref() {
                            if !pa.trim().is_empty() {
                                st.pair_address = Some(pa.clone());
                            }
                        }
                    }
                }
            }

                                            // 4) Helius ingest
                            // 4a) wallet-learning mode (seed wallets -> discover new wallets/mints)
                            let wallets: Vec<String> = cfg.helius_wallets
                                .split(',')
                                .map(|s| s.trim().to_string())
                                .filter(|s| !s.is_empty())
                                .collect();

                            if !wallets.is_empty() {
                                let _ = crate::helius::ingest::ingest_wallet_activity(
                                    &cfg,
                                    &mut db,
                                    &mut coins,
                                    &wallets,
                                ).await;
                            }

                            // 4b) per-coin mode (active coins w/ pair_address -> real signers_5m)
                            if !active.is_empty() {
                                let _ = crate::helius::per_coin::ingest_pairs_for_active(
                                    &cfg,
                                    &mut db,
                                    &mut coins,
                                    &active,
                                ).await;
                            }

                            // Wallet reputation scoring (incremental)
    let _ = crate::scoring::wallet_rep::update_wallet_reputation(&mut db, crate::time::now() as i64);

    // 5) Score & manage (decides active/queue/calls)
    crate::scoring::engine::score_and_manage(
        &cfg,
        &mut coins,
        &mut active,
        &mut queue,
        &mut calls,
        &market,
        &mut shadow,
        &mut db,
    );

    // 6) Evaluate outcomes for older calls (writes truth to DB)
    let now_ts = crate::time::now() as i64;
    let _ = crate::scoring::call_outcomes::evaluate_call_outcomes(&mut db, &market, now_ts);

    // sleep
    tokio::time::sleep(Duration::from_secs(cfg.main_loop_sleep)).await;
                        }
                    } => {}

                    _ = signal::ctrl_c() => {
                        println!("\n{}🛑 Ctrl+C — saving & exiting...{}", fmt::ORANGE, fmt::RESET);
                        let _ = save_reputation();
                    }
                }
}
