use crate::types::CallRecord;

pub fn print_call(c: &CallRecord) {
    let pink = "\x1b[38;5;213m";
    let reset = "\x1b[0m";

    println!(
        "📣 CALL mint={pink}{}{reset} score={} ts={}",
        c.mint, c.score, c.ts
    );
}
