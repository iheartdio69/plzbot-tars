// src/resolver.rs
use crate::config::Config;
use crate::db::Db;
use crate::market::cache::MarketCache;
use anyhow::Result;

pub fn resolve_calls(_cfg: &Config, db: &mut Db, market: &MarketCache, now_ts: i64) -> Result<()> {
    crate::scoring::call_outcomes::evaluate_call_outcomes(db, market, now_ts)
}
