use crate::config::Config;
use crate::market::cache::MarketCache;
use crate::scoring::shadow;
use crate::types::{CallRecord, CoinState, WhaleTier};
use std::collections::{HashMap, VecDeque};
pub fn score_and_manage(
    cfg: &Config,
    coins: &mut HashMap<String, CoinState>,
    active: &mut Vec<String>,
    queue: &mut VecDeque<String>,
    calls: &mut Vec<CallRecord>,
    market: &MarketCache,
    shadow_map: &mut shadow::ShadowMap,
    db: &mut crate::db::Db,
) {
    let now = crate::time::now();
    let now_ts = now as i64;

    // 1) score each coin
    for (mint, st) in coins.iter_mut() {
        // market gate
        let Some(ms) = market.map.get(mint) else {
            st.score = 0;
            continue;
        };

        let fdv = ms.fdv.unwrap_or(0.0);
        let liq = ms.liq.unwrap_or(0.0);
        let tx_5m = ms.tx_5m.unwrap_or(0) as usize;
        st.tx_5m = tx_5m;

        // keep last 20m of events (used later for quality sampling / future features)
        let keep_since = now.saturating_sub(1200);
        st.events.retain(|e| e.ts >= keep_since);

        // ✅ UNIQUE SIGNERS: SOURCE OF TRUTH = DB EDGES (last 5m)
        st.unique_signers_5m = db.signers_5m(now_ts, mint.as_str()).unwrap_or(0) as usize;

        // ---- quality signers (wallet rep) ----
        let cutoff = now.saturating_sub(300);
        let mut quality_sum: i64 = 0;
        let mut quality_hits: i64 = 0;

        let mut sampled = 0usize;
        for e in st.events.iter().rev() {
            if e.ts < cutoff {
                break;
            }
            sampled += 1;
            if sampled > 200 {
                break;
            }

            let sc = db.wallet_score(&e.wallet).unwrap_or(0);

            // only count non-trivial wallets
            if sc >= 10 {
                quality_hits += 1;
                quality_sum += sc.min(500);
            }
        }

        // baseline score
        let mut score: i32 = 0;

        // market bands
        if fdv >= cfg.min_watch_fdv_usd && fdv <= cfg.max_watch_fdv_usd {
            score += 15;
        }
        if liq >= cfg.min_liq_usd {
            score += 15;
        }

        if let Some(pct) = db.fdv_change_pct(mint.as_str(), now_ts, 300) {
            if pct >= 0.30 {
                score += 15; // +20% in 5m = strong momentum
            } else if pct >= 0.20 {
                score += 10;
            } else if pct >= 0.10 {
                score += 5;
            }
        }

        let fdv_delta_30s = db
            .fdv_delta_recent(mint.as_str(), now_ts, 30)
            .unwrap_or(0.0);

        // Reaction bonus: FDV jumping fast
        if fdv_delta_30s >= 10_000.0 {
            score += 10;
        }
        if fdv_delta_30s >= 25_000.0 {
            score += 15;
        }
        if fdv_delta_30s >= 50_000.0 {
            score += 25;
        }

        // activity
        if st.tx_5m >= 5 {
            score += 15;
        }

        // signer gate
        if !st.events.is_empty() {
            match st.unique_signers_5m {
                0 => score -= 5,     // mild penalty
                1..=2 => score += 5, // early cluster
                3..=5 => score += 10,
                _ => score += 20,
            }
        }

        // quality bonus (gentle)
        if quality_hits >= 2 {
            score += 10;
        }
        if quality_hits >= 5 {
            score += 10;
        }
        if quality_sum >= 250 {
            score += 10;
        }

        // whales (last 5m)
        let whale_cutoff = now.saturating_sub(300);
        let mut beluga: i32 = 0;
        let mut blue: i32 = 0;

        for e in st.events.iter().rev() {
            if e.ts < whale_cutoff {
                break;
            }
            match e.tier {
                WhaleTier::Beluga => beluga += 1,
                WhaleTier::Blue => blue += 1,
                WhaleTier::None => {}
            }
        }

        score += beluga * 5;
        score += blue * 10;

        // shadow penalty
        if shadow::is_shadowed(shadow_map, mint, now) {
            score -= 50;
        }

        st.score = score;

        // low-score streak for demotion
        if st.score < cfg.score_demote {
            st.low_score_streak = st.low_score_streak.saturating_add(1);
        } else {
            st.low_score_streak = 0;
        }

        println!(
            "DBG score mint={} score={} tx_5m={} signers_5m={} q_hits={} q_sum={} events={} first_seen={}",
            crate::fmt::mint(mint),
            crate::fmt::score_fmt(st.score),
            st.tx_5m,
            st.unique_signers_5m,
            quality_hits,
            quality_sum,
            st.events.len(),
            st.first_seen
        );

        // Optional: snapshot each tick (comment out if too noisy)
        let _ = db.insert_snapshot(
            now_ts,
            mint,
            Some(fdv),
            ms.tx_5m,
            st.score,
            st.unique_signers_5m as u64,
            st.events.len(),
            st.first_seen,
            active.contains(mint),
            false,
        );
    }

    // 2) recompute active list: drop demoted
    active.retain(|mint| {
        if let Some(st) = coins.get(mint) {
            if u32::from(st.low_score_streak) >= cfg.demote_streak {
                shadow::shadow_for(shadow_map, mint, now, 120);
                false
            } else {
                true
            }
        } else {
            false
        }
    });

    // 3) fill queue with candidates
    for (mint, st) in coins.iter() {
        if st.score >= 20
            && !active.contains(mint)
            && !queue.contains(mint)
            && !shadow::is_shadowed(shadow_map, mint, now)
        {
            let fdv_dbg = market.map.get(mint).and_then(|ms| ms.fdv).unwrap_or(0.0);
            eprintln!(
                "DBG queue_add mint={} score={} fdv={:.0} tx_5m={}",
                crate::fmt::mint(mint),
                st.score,
                fdv_dbg,
                st.tx_5m
            );

            queue.push_back(mint.clone());
        }
    }

    // 4) promote from queue into active
    while active.len() < cfg.max_active_coins {
        let Some(mint) = queue.pop_front() else {
            break;
        };
        if active.contains(&mint) {
            continue;
        }

        // DEBUG: promoting
        eprintln!(
            "DBG promote_active mint={} score={} pair={:?}",
            crate::fmt::mint(&mint),
            coins.get(&mint).map(|s| s.score).unwrap_or(0),
            coins.get(&mint).and_then(|s| s.pair_address.clone())
        );

        active.push(mint.clone());

        if let Some(st) = coins.get_mut(&mint) {
            st.active = true;
        }

        println!(
            "{}",
            crate::fmt::active_line(&mint, coins.get(&mint).map(|s| s.score).unwrap_or(0))
        );
    }

    // 5) create calls from active coins that pass call fdv band
    for mint in active.iter() {
        let Some(ms) = market.map.get(mint) else {
            continue;
        };
        let fdv = ms.fdv.unwrap_or(0.0);

        if fdv >= cfg.min_call_fdv_usd && fdv <= cfg.max_call_fdv_usd {
            if calls.iter().any(|c| c.mint == *mint) {
                continue;
            }

            let tx5: u64 = ms.tx_5m.unwrap_or(0);
            let signers_u: usize = coins.get(mint).map(|s| s.unique_signers_5m).unwrap_or(0);

            // spam guard: don't call "0 signers + low tx"
            if signers_u == 0 && tx5 < 50 {
                continue;
            }

            let sc = coins.get(mint).map(|s| s.score).unwrap_or(0);
            calls.push(CallRecord {
                mint: mint.clone(),
                ts: now,
                score: sc,
            });

            let signers: u64 = signers_u as u64;
            let ev: usize = coins.get(mint).map(|s| s.events.len()).unwrap_or(0);

            // --- GAMBOL heuristic (tweak thresholds) ---
            let is_gambol = signers == 0 && tx5 >= 200;

            // --- terminal output (ANSI ok) ---
            let term_line = if is_gambol {
                crate::fmt::red(&crate::fmt::call_line(
                    mint.as_str(),
                    fdv,
                    sc,
                    tx5,
                    signers as usize,
                    ev,
                ))
            } else {
                crate::fmt::call_line(mint.as_str(), fdv, sc, tx5, signers as usize, ev)
            };
            println!("{}", term_line);
            let tag = if is_gambol { Some("GAMBOL") } else { None };
            let _ = db.insert_call(now_ts, mint, fdv, sc, tx5, signers, ev, tag);
            let _ = db.insert_snapshot(
                now_ts,
                mint,
                Some(fdv),
                ms.tx_5m,
                sc,
                signers,
                ev,
                coins.get(mint).map(|s| s.first_seen).unwrap_or(0),
                true,
                true,
            );

            // ----------------------------
            // Spam guard (tx spam w/ no attributed signers)
            // ----------------------------
            let tx_spam = tx5 >= 200 && signers == 0 && ev == 0;
            let low_signal = tx5 >= 80 && signers == 0 && ev == 0;

            if tx_spam || low_signal {
                eprintln!(
                    "🧯 spam_guard skip mint={} tx_5m={} signers={} events={}",
                    crate::fmt::mint(mint),
                    tx5,
                    signers,
                    ev
                );
                continue;
            }

            // ---- CALL LOG (CSV) ----
            let ts = now_ts;
            let log = format!("{},{},{:.0},{},{},{}", ts, mint, fdv, sc, tx5, signers);
            crate::call_log::append_call_line(&log);

            // ----------------------------
            // Fingerprints for THIS CALL
            // ----------------------------

            // A) Top wallets by activity/edges on this mint (proxy for “top holders-ish”)
            if let Ok(top) = db.top_wallets_for_mint(mint.as_str(), 20) {
                for (w, edges) in top.iter() {
                    let _ = db.insert_call_wallet_fingerprint(
                        mint.as_str(),
                        now_ts,
                        w.as_str(),
                        "top_edges",
                        *edges as f64, // <-- IMPORTANT: deref
                    );
                    let _ = db.watchlist_touch_with_tag(w.as_str(), now_ts, "top_edges");
                }
            }

            // B) Early cluster wallets (first ~60s of mint activity)
            if let Ok(early) = db.early_wallets_for_mint(mint.as_str(), 60, 30) {
                for (w, _edges, first_seen_ts) in early.iter() {
                    // metric = minutes-from-(window start). Keep it simple for now.
                    let minutes_from_window_start =
                        ((first_seen_ts.saturating_sub((now_ts - 300) as i64)) as f64) / 60.0;

                    let _ = db.insert_call_wallet_fingerprint(
                        mint.as_str(),
                        now_ts,
                        w.as_str(),
                        "early",
                        minutes_from_window_start,
                    );
                    let _ = db.watchlist_touch_with_tag(w.as_str(), now_ts, "early");
                }
            }
        }
    }
}
